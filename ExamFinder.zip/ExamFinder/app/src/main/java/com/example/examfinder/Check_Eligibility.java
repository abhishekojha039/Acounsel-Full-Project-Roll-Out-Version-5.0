package com.example.examfinder;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class Check_Eligibility extends AppCompatActivity {
    Spinner spinner1,spinner2;
    String str="";
    ArrayAdapter adapter1,adapter2,adapter3;
    Button submit;
    String d;
    String nm[]={"Maths","Biology","Commerce"};
   // String stream1[]={"12 th","B.e/B.TECH","MBA","Architecture","Polytechnic"};
    String stream2[]={"A","B","C","D","E"};
    String stream3[]={"Commerce_12th","Commerce_Bba","Commerce_BCA","Commerce_Bcom","Commerce_Bms","Commerce_CA"};
    String stream1[]={"Math_12th","Math_Btech","Maths_MBA","A_list","Poly_list"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check__eligibility);
        spinner1=findViewById(R.id.spinner1);
        spinner2=findViewById(R.id.spinner2);
        submit=findViewById(R.id.submit);


        ArrayAdapter adapter=new ArrayAdapter(Check_Eligibility.this,android.R.layout.simple_expandable_list_item_1,nm);
        spinner1.setAdapter(adapter);
       adapter.notifyDataSetChanged();
        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                str=""+nm[position];
             //   Toast.makeText(Check_Eligibility.this, ""+str, Toast.LENGTH_SHORT).show();
              //  adapter1=new ArrayAdapter(Check_Eligibility.this,android.R.layout.simple_expandable_list_item_1,stream1);
                if(str.equals("Maths"))
                {//
                   // Toast.makeText(Check_Eligibility.this, ""+str, Toast.LENGTH_SHORT).show();
                    adapter1=new ArrayAdapter(Check_Eligibility.this,android.R.layout.simple_expandable_list_item_1,stream1);

                }
                else   if(str.equals("Biology"))
                {
                    //Toast.makeText(Check_Eligibility.this, ""+str, Toast.LENGTH_SHORT).show();
                    adapter1=new ArrayAdapter(Check_Eligibility.this,android.R.layout.simple_expandable_list_item_1,stream2);

                }
                else  if(str.equals("Commerce"))
                {
                    adapter1=new ArrayAdapter(Check_Eligibility.this,android.R.layout.simple_expandable_list_item_1,stream3);

                }
                adapter1.notifyDataSetChanged();
                spinner2.setAdapter(adapter1);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });



        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                d=""+adapter1.getItem(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try
                {
                  //  Toast.makeText(Check_Eligibility.this, ""+d, Toast.LENGTH_SHORT).show();
                    Class cls=Class.forName("com.example.examfinder."+d);
                    Intent i=new Intent(Check_Eligibility.this,cls);
                    startActivity(i);
                }
                catch (ClassNotFoundException e)
                {
                    Toast.makeText(Check_Eligibility.this, ""+d, Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
}
