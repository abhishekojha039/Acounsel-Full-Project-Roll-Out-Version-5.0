package com.example.examfinder;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class Math_Mba_Govt extends AppCompatActivity {
    ListView lstvw;
    String nm[]={"personnel officer in  bank","Marketing Officer in bank","General Manager Posts at various Psus and Banks"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_math__mba__govt);
        lstvw=findViewById(R.id.lstvw);
        ArrayAdapter adapter=new ArrayAdapter(Math_Mba_Govt.this,R.layout.listview,nm);
        lstvw.setAdapter(adapter);
        lstvw.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String str=""+nm[position];
                if(str.equals("personnel officer in  bank"))
                {

                }
                else if(str.equals("Marketing Officer in bank"))
                {

                }
                else if(str.equals("General Manager Posts at various Psus and Banks"))
                {

                }
            }
        });
    }
}
