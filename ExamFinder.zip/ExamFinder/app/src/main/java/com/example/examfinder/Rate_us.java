package com.example.examfinder;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
public class Rate_us extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_us);
    }
}
